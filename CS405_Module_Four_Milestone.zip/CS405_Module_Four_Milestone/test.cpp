#include "pch.h"

class Environment : public ::testing::Environment {
public:
    ~Environment() override {}
    void SetUp() override {
        srand(time(nullptr));
    }
    void TearDown() override {}
};

class CollectionTest : public ::testing::Test {
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override {
        collection.reset(new std::vector<int>);
    }
    void TearDown() override {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count) {
        if (count <= 0) return;
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

TEST_F(CollectionTest, CollectionSmartPointerIsNotNull) {
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

TEST_F(CollectionTest, IsEmptyOnCreate) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, CanAddToEmptyVector) {
    add_entries(1);
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

TEST_F(CollectionTest, CanAddFiveValuesToVector) {
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualSize) {
    for (int count : {1, 5, 10}) {
        collection->clear();
        add_entries(count);
        ASSERT_GE(collection->max_size(), collection->size());
    }
}

TEST_F(CollectionTest, CapacityGreaterThanOrEqualSize) {
    for (int count : {1, 5, 10}) {
        collection->clear();
        add_entries(count);
        ASSERT_GE(collection->capacity(), collection->size());
    }
}

TEST_F(CollectionTest, ResizingIncreasesCollection) {
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);
}

TEST_F(CollectionTest, ResizingDecreasesCollection) {
    collection->resize(10);
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, ResizingToZeroClearsCollection) {
    collection->resize(10);
    collection->resize(0);
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ClearErasesCollection) {
    add_entries(10);
    collection->clear();
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, EraseBeginEndErasesCollection) {
    add_entries(10);
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->empty());
}

TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize) {
    collection->reserve(50);
    ASSERT_GE(collection->capacity(), 50);
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, ThrowsOutOfRangeWhenAccessingInvalidIndex) {
    add_entries(5);
    ASSERT_THROW(collection->at(10), std::out_of_range);
}

TEST_F(CollectionTest, CanAccessFirstElementAfterAdding) {
    add_entries(1);
    ASSERT_NO_THROW(collection->at(0));
}

TEST_F(CollectionTest, PreventEraseBeyondEnd) {
    add_entries(5);

    // Attempt to erase with a valid iterator
    auto valid_iterator = collection->begin() + collection->size(); // Points to end()
    ASSERT_NO_THROW({
        if (valid_iterator <= collection->end()) {
            collection->erase(valid_iterator - 1); // Erase the last valid element
        }
        });

    // Check that the size has decreased
    ASSERT_EQ(collection->size(), 4);
}
