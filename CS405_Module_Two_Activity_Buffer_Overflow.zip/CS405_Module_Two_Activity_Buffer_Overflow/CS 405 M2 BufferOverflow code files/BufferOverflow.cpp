// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <cstring> // For strncpy

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // The account_number variable remains constant and is declared directly before the input buffer.
    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value (max 19 characters): ";

    // Secure input handling: using getline to limit input size to prevent buffer overflow
    std::cin.getline(user_input, sizeof(user_input));

    // Check if the input exceeds the buffer size
    if (std::cin.fail() || strlen(user_input) >= sizeof(user_input) - 1)
    {
        // Clear the error flag to ensure subsequent input operations are valid
        std::cin.clear();
        // Discard excess input to avoid corrupting the buffer
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        // Notify the user about the overflow attempt
        std::cout << "Input too long. Maximum 19 characters allowed." << std::endl;
    }
    else
    {
        // Safely display the valid input back to the user
        std::cout << "You entered: " << user_input << std::endl;
    }

    // Display the account number to confirm it remains unaffected
    std::cout << "Account Number = " << account_number << std::endl;
}
